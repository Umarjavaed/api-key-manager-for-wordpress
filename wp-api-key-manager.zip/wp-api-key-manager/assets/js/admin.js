/* assets/js/admin.js */
jQuery(document).ready(function($){
    $('#wpakm-api-key-form').on('submit', function(e){
        e.preventDefault();
        
        var data = {
            action: 'generate_api_key',
            key_name: $('#key_name').val(),
            expiration_date: $('#expiration_date').val()
        };
        
        $.post(wpakm.ajax_url, data, function(response){
            if(response.success) {
                $('#wpakm-message').html('<div class="updated notice"><p>' + response.data.message + '<br>API Key: ' + response.data.api_key + '</p></div>');
                // Optionally, refresh the page or update the key list via AJAX.
                location.reload();
            } else {
                $('#wpakm-message').html('<div class="error notice"><p>' + response.data + '</p></div>');
            }
        });
    });
});
