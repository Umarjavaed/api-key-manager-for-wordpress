<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class API_Key_Endpoint {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }
    
    // Register REST API route for API key validation.
    public function register_routes() {
        register_rest_route( 'wpakm/v1', '/validate', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'validate_api_key' ),
            'permission_callback' => '__return_true'
        ));
    }
    
    // Validate the provided API key.
    public function validate_api_key( $request ) {
        $params = $request->get_json_params();
        if ( ! isset( $params['api_key'] ) ) {
            return new WP_Error( 'missing_api_key', 'API key is missing', array( 'status' => 400 ) );
        }
        
        $api_key = sanitize_text_field( $params['api_key'] );
        global $wpdb;
        $table_name = $wpdb->prefix . 'api_keys';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE api_key = %s", $api_key ) );
        
        if ( ! $row ) {
            return array( 'message' => 'Invalid API key.' );
        }
        
        $current_time = current_time( 'mysql' );
        if ( $row->expiration_date < $current_time ) {
            return array( 'message' => 'API key expired.' );
        }
        
        return array( 'message' => 'API key is valid.' );
    }
}
