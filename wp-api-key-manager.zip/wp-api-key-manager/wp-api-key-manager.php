<?php
/*
Plugin Name: WP API Key Manager
Description: Generate and manage API keys with expiration dates.
Version: 1.0
Author: Your Name
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WPAKM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Activation hook to create the API keys table.
register_activation_hook( __FILE__, 'wpakm_install' );
function wpakm_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'api_keys';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        api_key varchar(64) NOT NULL,
        key_name varchar(255) NOT NULL,
        expiration_date datetime NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY api_key (api_key)
    ) $charset_collate;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

// Include necessary files.
require_once WPAKM_PLUGIN_DIR . 'includes/class-api-key-manager.php';
require_once WPAKM_PLUGIN_DIR . 'includes/class-api-key-endpoint.php';

// Initialize the admin dashboard.
if ( is_admin() ) {
    $api_key_manager = new API_Key_Manager();
}

// Initialize the API endpoint.
$api_key_endpoint = new API_Key_Endpoint();
