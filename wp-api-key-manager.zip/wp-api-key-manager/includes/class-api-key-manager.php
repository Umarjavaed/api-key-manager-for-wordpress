<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class API_Key_Manager {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_ajax_generate_api_key', array( $this, 'generate_api_key' ) );
    }
    
    // Add a new admin menu page.
    public function add_menu() {
        add_menu_page(
            'API Key Manager',
            'API Keys',
            'manage_options',
            'wp-api-key-manager',
            array( $this, 'dashboard_page' ),
            'dashicons-admin-network',
            80
        );
    }
    
    // Enqueue admin CSS and JavaScript.
    public function enqueue_assets($hook) {
        if ( $hook !== 'toplevel_page_wp-api-key-manager' ) return;
        wp_enqueue_style( 'wpakm-admin-css', plugins_url( '../assets/css/admin.css', __FILE__ ) );
        wp_enqueue_script( 'wpakm-admin-js', plugins_url( '../assets/js/admin.js', __FILE__ ), array('jquery'), null, true );
        wp_localize_script( 'wpakm-admin-js', 'wpakm', array(
            'ajax_url' => admin_url( 'admin-ajax.php' )
        ));
    }
    
    // Render the dashboard page.
    public function dashboard_page() {
        ?>
        <div class="wrap">
            <h1>API Key Manager</h1>
            <form id="wpakm-api-key-form">
                <table class="form-table">
                    <tr>
                        <th><label for="key_name">API Key Name</label></th>
                        <td><input type="text" id="key_name" name="key_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="expiration_date">Expiration Date</label></th>
                        <td><input type="datetime-local" id="expiration_date" name="expiration_date" required></td>
                    </tr>
                </table>
                <?php submit_button( 'Generate API Key', 'primary', 'generate_api_key_button' ); ?>
            </form>
            <div id="wpakm-message"></div>
            <h2>Existing API Keys</h2>
            <?php $this->list_api_keys(); ?>
        </div>
        <?php
    }
    
    // AJAX callback for generating a new API key.
    public function generate_api_key() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }
        
        $key_name = sanitize_text_field( $_POST['key_name'] );
        $expiration_date = sanitize_text_field( $_POST['expiration_date'] );
        
        if ( empty($key_name) || empty($expiration_date) ) {
            wp_send_json_error( 'All fields are required.' );
        }
        
        // Generate a unique API key.
        $api_key = bin2hex(random_bytes(32));
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'api_keys';
        $result = $wpdb->insert( $table_name, array(
            'api_key'         => $api_key,
            'key_name'        => $key_name,
            'expiration_date' => date( 'Y-m-d H:i:s', strtotime( $expiration_date ) ),
        ));
        
        if ( $result ) {
            wp_send_json_success( array(
                'message' => 'API key generated successfully!',
                'api_key' => $api_key,
            ));
        } else {
            wp_send_json_error( 'Database error.' );
        }
    }
    
    // List all generated API keys.
    private function list_api_keys() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'api_keys';
        $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY created_at DESC" );
        
        if ( $results ) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Name</th><th>API Key</th><th>Expiration Date</th><th>Created At</th></tr></thead><tbody>';
            foreach ( $results as $row ) {
                echo '<tr>';
                echo '<td>' . esc_html( $row->key_name ) . '</td>';
                echo '<td>' . esc_html( $row->api_key ) . '</td>';
                echo '<td>' . esc_html( $row->expiration_date ) . '</td>';
                echo '<td>' . esc_html( $row->created_at ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>No API keys found.</p>';
        }
    }
}
